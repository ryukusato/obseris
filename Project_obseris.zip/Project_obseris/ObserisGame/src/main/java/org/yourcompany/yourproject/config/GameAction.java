package org.yourcompany.yourproject.config;
public enum GameAction {
    MOVE_LEFT,
    MOVE_RIGHT,
    ROTATE_LEFT,
    ROTATE_RIGHT,
    SOFT_DROP,
    HARD_DROP,
    HOLD,
    NONE // 何もしない
}