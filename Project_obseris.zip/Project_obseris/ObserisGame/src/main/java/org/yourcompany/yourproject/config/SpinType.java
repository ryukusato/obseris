package org.yourcompany.yourproject.config;
public enum SpinType {
    NONE,
    T_SPIN,
    T_SPIN_MINI
}