package org.yourcompany.yourproject.config;
public enum PlayerType {
    HUMAN,
    AI
}